<?php
/*GOOGLE MAP*/
add_shortcode('vc_g_map', 'vc_g_map_f');
function vc_g_map_f( $atts, $content = null)
{
  extract(shortcode_atts(
    array(
      'api_key' => null,
      'address' => '235 Bowery, New York, NY',
      'zoom' => '16',
      'height' => '430px',
    ), $atts)
  );

if($api_key == true) {
  $output ='<div id="map" style="height:'.$height.'"></div>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key='.$api_key.'"></script>
         <script>
var geocoder;
var map;
var marker;
var address = "'.$address.'";

function initialize() {
  geocoder = new google.maps.Geocoder();
  var latlng = new google.maps.LatLng(-34.397, 150.644);

  var myOptions = {
    zoom: '.$zoom.',
    center: latlng,
    disableDefaultUI: true,
    scrollwheel: false,
    draggable: false,
    styles:
            [{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}],
    mapTypeControl: false,
      mapTypeControlOptions: {
        style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
      },
    navigationControl: false,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };

  map = new google.maps.Map(document.getElementById("map"), myOptions);

  if (geocoder) {
    geocoder.geocode({
      "address": address
    }, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        if (status != google.maps.GeocoderStatus.ZERO_RESULTS) {
          map.setCenter(results[0].geometry.location);

          var infowindow = new google.maps.InfoWindow({
            content: "<b>" + address + "</b>",
            size: new google.maps.Size(150, 50)
          });

          var marker = new google.maps.Marker({
            position: results[0].geometry.location,
            map: map,
            icon: "'.get_template_directory_uri().'/assets/images/map-marker.png",
            title: address
          });
          google.maps.event.addListener(marker, "click", function() {
            infowindow.open(map, marker);
          });
        } else {
          alert("No results found");
        }
      } else {
        alert("Geocode was not successful for the following reason: " + status);
      }
    });
  }
};
google.maps.event.addDomListener(window, "load", initialize);</script>';
} else {
    $output ='<div id="map" style="height:'.$height.'"><p style="text-align: center;margin-bottom: 0;line-height: '.$height.';font-size: 21px;background:#fff;border-top:2px solid #eee;">Please, set up your API key for display Google Maps.</p></div>';;
};
  return $output;
};


vc_map( array(
  "name" => __("Google Map",'pheromone'),
  "base" => "vc_g_map",
  "category" => __('Pheromone','pheromone'),
  "params" => array(
    array(
      "type" => "textfield",
      "admin_label" => true,
      "param_name" => "api_key",
      "heading" => __("API Key", 'pheromone'),
      "description" => 'Enter your own key for enable Google Maps. <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">Create new key.</a>', 'pheromone',
    ),
    array(
      "type" => "textfield",
      "admin_label" => true,
      "param_name" => "address",
      "heading" => __("Addres", 'pheromone'),
      "value" => '235 Bowery, New York, NY',
    ),
    array(
      "type" => "textfield",
      "admin_label" => true,
      "param_name" => "zoom",
      "heading" => __("Zoom", 'pheromone'),
      "value" => '16',
    ),
    array(
      "type" => "textfield",
      "admin_label" => true,
      "param_name" => "height",
      "heading" => __("Map Height", 'pheromone'),
      "value" => '430px',
    ), 
  )
) );